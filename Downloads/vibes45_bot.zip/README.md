# Vibes45 Bot

Простой Telegram-бот на aiogram
